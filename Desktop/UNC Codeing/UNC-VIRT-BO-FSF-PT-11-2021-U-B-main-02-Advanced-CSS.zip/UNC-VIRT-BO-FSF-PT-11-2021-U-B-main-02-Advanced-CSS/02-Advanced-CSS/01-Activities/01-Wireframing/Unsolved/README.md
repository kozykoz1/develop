# Activity 2: Wireframing Unsolved

* The rows are highlighted in red and the columns are highlighted in blue.

![Example of an unfinished wireframe with its row and columns highlighted](./assets/Images/02-unfinished-wireframe.png)

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.